/*
Objects.h
此文件包含程序中需要使用到的各个 class 定义
作者：CataLpa
*/

#include <iostream>
#include <fstream>
#include <string>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include "json.hpp"

using namespace std;
using namespace configor;

#define MAXLEN     2048
#define HEADERLEN  24
#define MAGIC      "MULBERRY"
#define VERSION    1
#define MAXOPCODE  20
#define ENCFLAG    1

int do_enc_dec(char* buf, unsigned int length);

class RequestData
{
    private:
        unsigned int opcode;
        unsigned int encflag;
        unsigned int encsession;
        char* payload;

    public:
        RequestData();    // con
        ~RequestData();   // decon
        RequestData(const RequestData& requestData);    // copy con
        unsigned int get_opcode(void);
        unsigned int get_encflag(void);
        unsigned int get_encsession(void);
        void get_payload(char* buf);
        void set_opcode(unsigned int _opcode);
        void set_encflag(unsigned int _encflag);
        void set_encsession(unsigned int _encsession);
        void set_payload(char* buf);
};

class Request
{
    private:
        long long int magic;
        unsigned int version;
        unsigned int timestamp;
        unsigned int CRC;
        unsigned int data_len;
        RequestData request_data;    // point to RequestData obj

    public:
        Request();    // con
        ~Request();   // decon
        Request(const Request& request);    // copy con
        long long int get_magic(void);
        unsigned int get_version(void);
        unsigned int get_timestamp(void);
        unsigned int get_CRC(void);
        unsigned int get_data_len(void);
        RequestData* get_request_data(void);
        void set_magic(long long int _magic);
        void set_version(unsigned int _version);
        void set_timestamp(unsigned int _timestamp);
        void set_CRC(unsigned int _CRC);
        void set_data_len(unsigned int _data_len);
        void set_request_data(RequestData requestData);
};

class ResponseData
{
    private:
        unsigned int status;
        unsigned int encflag;
        char* payload;
    
    public:
        ResponseData();
        ~ResponseData();
        ResponseData(const ResponseData& responseData);
        unsigned int get_status(void);
        unsigned int get_encflag(void);
        void get_payload(char* buf);
        void set_status(unsigned int _status);
        void set_encflag(unsigned int _encflag);
        void set_payload(char* buf);
};

class Response
{
    private:
        long long int magic;
        unsigned int version;
        unsigned int timestamp;
        unsigned int CRC;
        unsigned int data_len;
        ResponseData response_data;    // point to RequestData obj

    public:
        Response();    // con
        ~Response();   // decon
        Response(const Response& response);    // copy con
        long long int get_magic(void);
        unsigned int get_version(void);
        unsigned int get_timestamp(void);
        unsigned int get_CRC(void);
        unsigned int get_data_len(void);
        ResponseData* get_response_data(void);
        void set_magic(long long int _magic);
        void set_version(unsigned int _version);
        void set_timestamp(unsigned int _timestamp);
        void set_CRC(unsigned int _CRC);
        void set_data_len(unsigned int _data_len);
        void set_response_data(ResponseData responseData);
};

class Check
{
    public:
        Check();
        ~Check();
        int key_check(Request& request);
        int crc_check(Request& request);
        int encsession_check(Request& request);
};

class Login
{
    private:
        static const unsigned int opcode = 0;
        string username;
        string password;
        const char* config_file = "/home/iot/Desktop/Cpp/config.ini";

    public:
        Login();
        ~Login();
        string get_username();
        void set_username(string buf);
        string get_password();
        void set_password(string buf);
        unsigned int get_opcode();
        json login();    // handler
};

class Putkey
{
    private:
        static const unsigned int opcode = 1;
    public:
        Putkey();
        ~Putkey();
        json putkey(Request& request);    // handler
};

class Logout
{
    private:
        static const unsigned int opcode = 2;
    
    public:
        Logout();
        ~Logout();
        unsigned int get_opcode();
        int logout();
};

class GetLogo
{
    private:
        static const unsigned int opcode = 2;
        string logo_path_format = "/home/iot/Desktop/Cpp/%s.png";
        unsigned int max_filename_len = 36;
    
    public:
        GetLogo();
        ~GetLogo();
        json getlogo(string path);
};

class Ping
{
    private:
        string ip_address;
        unsigned int count;
    
    public:
        Ping();
        ~Ping();
        void set_ip_address(string ip);
        void set_count(unsigned int _count);
        json ping();

};