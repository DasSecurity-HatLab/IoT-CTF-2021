#include "Objects.h"
#include "Parser.h"
#include "crc.h"
#include "base64.h"

unsigned int encsession;
string enc_key;

void io_init(){
    setvbuf(stdin, 0, 2, 0);
    setvbuf(stdout, 0, 2, 0);
    setvbuf(stderr, 0, 2, 0);
}

unsigned int RequestData::get_opcode(void)
{
    return opcode;
}

unsigned int RequestData::get_encflag(void)
{
    return encflag;
}

unsigned int RequestData::get_encsession(void)
{
    return encsession;
}

void RequestData::get_payload(char *buf)
{
    memcpy((void *)buf, (void *)payload, MAXLEN);
}

void RequestData::set_opcode(unsigned int _opcode)
{
    opcode = _opcode;
}

void RequestData::set_encflag(unsigned int _encflag)
{
    encflag = _encflag;
}

void RequestData::set_encsession(unsigned int _encsession)
{
    encsession = _encsession;
}

void RequestData::set_payload(char *buf)
{
    memcpy((void *)payload, (void *)buf, MAXLEN);
}

RequestData::RequestData(void)
{
    cout << "[*] RequestData object created." << endl;
    payload = new char[MAXLEN];
}

RequestData::~RequestData(void)
{
    cout << "[*] RequestData object deleted." << endl;
    delete payload;
}

RequestData::RequestData(const RequestData &requestData)
{
    cout << "[*] RequestData object copy." << endl;
    opcode = requestData.opcode;
    encflag = requestData.encflag;
    encsession = requestData.encsession;
    payload = new char[MAXLEN];
    memcpy(payload, requestData.payload, MAXLEN);
}

long long int Request::get_magic(void)
{
    return magic;
}

unsigned int Request::get_version(void)
{
    return version;
}

unsigned int Request::get_timestamp(void)
{
    return timestamp;
}

unsigned int Request::get_CRC(void)
{
    return CRC;
}

unsigned int Request::get_data_len(void)
{
    return data_len;
}

RequestData* Request::get_request_data(void)
{
    return &request_data;
}

void Request::set_magic(long long int _magic)
{
    magic = _magic;
}

void Request::set_version(unsigned int _version)
{
    version = _version;
}

void Request::set_timestamp(unsigned int _timestamp)
{
    timestamp = _timestamp;
}

void Request::set_CRC(unsigned int _CRC)
{
    CRC = _CRC;
}

void Request::set_data_len(unsigned int _data_len)
{
    data_len = _data_len;
}

void Request::set_request_data(RequestData requestData)
{
    request_data = requestData; // copy con called
}

Request::Request()
{
    cout << "[*] Request object created." << endl;
}

Request::~Request()
{
    cout << "[*] Request object deleted." << endl;
}

Request::Request(const Request &request)
{
    cout << "[*] Request object copy." << endl;
    magic = request.magic;
    version = request.version;
    timestamp = request.timestamp;
    CRC = request.CRC;
    data_len = request.data_len;
    request_data = request.request_data;
}

unsigned int ResponseData::get_status(void)
{
    return status;
}

unsigned int ResponseData::get_encflag(void)
{
    return encflag;
}

void ResponseData::get_payload(char *buf)
{
    memcpy((void *)buf, (void *)payload, MAXLEN);
}

void ResponseData::set_status(unsigned int _status)
{
    status = _status;
}

void ResponseData::set_encflag(unsigned int _encflag)
{
    encflag = _encflag;
}

void ResponseData::set_payload(char *buf)
{
    memcpy(payload, buf, MAXLEN);
}

ResponseData::ResponseData()
{
    cout << "[*] ResponseData object created." << endl;
    payload = new char[MAXLEN];
}

ResponseData::~ResponseData()
{
    cout << "[*] ResponseData object deleted." << endl;
    delete payload;
}

ResponseData::ResponseData(const ResponseData &responseData)
{
    status = responseData.status;
    encflag = responseData.encflag;
    payload = new char[MAXLEN];
    memcpy(payload, responseData.payload, MAXLEN);
}

long long int Response::get_magic(void)
{
    return magic;
}

unsigned int Response::get_version(void)
{
    return version;
}

unsigned int Response::get_timestamp(void)
{
    return timestamp;
}

unsigned int Response::get_CRC(void)
{
    return CRC;
}

unsigned int Response::get_data_len(void)
{
    return data_len;
}

ResponseData* Response::get_response_data(void)
{
    return &response_data;
}

void Response::set_magic(long long int _magic)
{
    magic = _magic;
}

void Response::set_version(unsigned int _version)
{
    version = _version;
}

void Response::set_timestamp(unsigned int _timestamp)
{
    timestamp = _timestamp;
}

void Response::set_CRC(unsigned int _CRC)
{
    CRC = _CRC;
}

void Response::set_data_len(unsigned int _data_len)
{
    data_len = _data_len;
}

void Response::set_response_data(ResponseData responseData)
{
    response_data = responseData;
}

Response::Response()
{
    cout << "[*] Response object created." << endl;
}

Response::~Response()
{
    cout << "[*] Response object deleted." << endl;
}

Response::Response(const Response &response)
{
    cout << "[*] Response object copy." << endl;
    magic = response.magic;
    version = response.version;
    timestamp = response.timestamp;
    CRC = response.CRC;
    data_len = response.data_len;
    response_data = response.response_data;
}

Parser::Parser()
{
    cout << "[*] Parser object created." << endl;
}

Parser::~Parser()
{
    cout << "[*] Parser object deleted." << endl;
}

int Parser::parseRequest(char *buf, int length, Request& request)
{
    unsigned int temp;
    // 1. check buf length, length should grater than HEADERLEN
    if (length <= HEADERLEN)
    {
        return FAIL;
    }
    // ================== HEADER ==================
    // 2. check magic
    char *tmp_magic = new char[8];
    int i;
    for (i = 0; i < 8; i++)
    {
        tmp_magic[i] = buf[i]; // get first 8 bytes from buf
    }
    tmp_magic[8] = '\x00';
    if (strcmp(tmp_magic, MAGIC))
    { // check is magic right?
        cout << "[-] Magic check failed!" << endl;
        return FAIL;
    }
    request.set_magic(0x4d554c4245525259);
    delete tmp_magic;

    // 3. check version
    char *tmp_version = new char[5];
    for (i; i < 12; i++)
    {
        tmp_version[i - 8] = buf[i]; // get 4 bytes
    }
    tmp_version[5] = '\x00';
    temp = (tmp_version[0] & 0xff) | ((tmp_version[1] << 8) & 0xffff) | ((tmp_version[2] << 16) & 0xffffff) | ((tmp_version[3] << 24) & 0xffffffff);
    if (temp != VERSION)
    {
        cout << "[-] Version check failed!" << endl;
        return FAIL;
    }
    request.set_version(temp);
    delete tmp_version;

    // 4. check timestamp: do not check for now
    char *tmp_timestamp = new char[5];
    for (i; i < 16; i++)
    {
        tmp_timestamp[i - 12] = buf[i];
    }
    tmp_timestamp[5] = '\x00';
    temp = (tmp_timestamp[0] & 0xff) | ((tmp_timestamp[1] << 8) & 0xffff) | ((tmp_timestamp[2] << 16) & 0xffffff) | ((tmp_timestamp[3] << 24) & 0xffffffff);
    request.set_timestamp(temp);
    delete tmp_timestamp;

    // 5. get crc, check it later
    char *tmp_crc = new char[5];
    for (i; i < 20; i++)
    {
        tmp_crc[i - 16] = buf[i];
    }
    tmp_crc[5] = '\x00';
    temp = (tmp_crc[0] & 0xff) | ((tmp_crc[1] << 8) & 0xffff) | ((tmp_crc[2] << 16) & 0xffffff) | ((tmp_crc[3] << 24) & 0xffffffff);
    request.set_CRC(temp);
    delete tmp_crc;

    // 6. check data_len
    char *tmp_datalen = new char[5];
    for (i; i < 24; i++)
    {
        tmp_datalen[i - 20] = buf[i];
    }
    tmp_datalen[5] = '\x00';
    temp = (tmp_datalen[0] & 0xff) | ((tmp_datalen[1] << 8) & 0xffff) | ((tmp_datalen[2] << 16) & 0xffffff) | ((tmp_datalen[3] << 24) & 0xffffffff);
    if (temp >= (MAXLEN - HEADERLEN))
    {
        cout << "[-] data_len too long!" << endl;
        return FAIL;
    }
    request.set_data_len(temp);
    delete tmp_datalen;
    // ================== HEADER CHECK END ==================

    // ================== PAYLOAD ==================
    RequestData* requestData = request.get_request_data();
    // 1. check opcode
    char *tmp_opcode = new char[5];
    for (i; i < 28; i++)
    {
        tmp_opcode[i - 24] = buf[i];
    }
    temp = (tmp_opcode[0] & 0xff) | ((tmp_opcode[1] << 8) & 0xffff) | ((tmp_opcode[2] << 16) & 0xffffff) | ((tmp_opcode[3] << 24) & 0xffffffff);
    if (temp > MAXOPCODE)
    {
        cout << "[-] OPCODE wrong!" << endl;
        return FAIL;
    }
    requestData->set_opcode(temp);
    delete tmp_opcode;

    // 2. check encflag
    char *tmp_encflag = new char[5];
    for (i; i < 32; i++)
    {
        tmp_encflag[i - 28] = buf[i];
    }
    temp = (tmp_encflag[0] & 0xff) | ((tmp_encflag[1] << 8) & 0xffff) | ((tmp_encflag[2] << 16) & 0xffffff) | ((tmp_encflag[3] << 24) & 0xffffffff);
    if (temp > ENCFLAG)
    {
        cout << "[-] ENCFLAG wrong!" << endl;
        return FAIL;
    }
    requestData->set_encflag(temp);
    delete tmp_encflag;

    // 3. get encsession, check it later
    char *tmp_encsession = new char[5];
    for (i; i < 36; i++)
    {
        tmp_encsession[i - 32] = buf[i];
    }
    temp = (tmp_encsession[0] & 0xff) | ((tmp_encsession[1] << 8) & 0xffff) | ((tmp_encsession[2] << 16) & 0xffffff) | ((tmp_encsession[3] << 24) & 0xffffffff);
    requestData->set_encsession(temp);

    // 4. get payload
    unsigned int tmp_data_len = request.get_data_len();
    char *tmp_payload = new char[MAXLEN];
    for (i; i < tmp_data_len + 36; i++)
    {
        tmp_payload[i - 36] = buf[i];
    }
    requestData->set_payload(tmp_payload);
    delete tmp_payload;
    // ================== PAYLOAD check end ==================
    cout << "[+] parse complete" << endl;
    return SUCCESS;
}

Login::Login(){
    cout << "[*] Login object created." << endl;
    username = new char[MAXLEN];
    password = new char[MAXLEN];
}

Login::~Login(){
    cout << "[*] Login object deleted." << endl;
}

string Login::get_username(){
    return username;
}

void Login::set_username(string buf){
    username = buf;
}

string Login::get_password(){
    return password;
}

void Login::set_password(string buf){
    password = buf;
}

unsigned int Login::get_opcode(){
    return opcode;
}

json Login::login(){
    json fail_payload;
    fail_payload["r"] = 0;
    cout << "[*] login handler called." << endl;
    // 1. get username and password from config file
    ifstream cf(config_file);
    if(!cf.is_open()){
        cout << "[-] Open config file error." << endl;
        return fail_payload;
    }
    string _str;
    string true_username;
    string true_password;
    getline(cf, true_username);    // get username
    getline(cf, true_password);    // get password
    cf.close();
    if(true_username.empty() || true_password.empty()){
        cout << "[-] Error reading config file" << endl;
        return fail_payload;
    }
    cout << "[+] true_username: " << true_username << endl;
    cout << "[+] true_password: " << true_password << endl;
    // 2. check username and password
    string tmp_username = username;
    string tmp_password = password;
    if(!true_username.compare(tmp_username) && !true_password.compare(tmp_password)){
        cout << "[+] login success" << endl;
        // 3. create encsession and return
        time_t t = time(0);
        encsession = (unsigned int) t;
        json succ;
        succ["r"] = 1;
        succ["e"] = encsession;
        return succ;
    }
    return fail_payload;
}

Putkey::Putkey(){
    cout << "[*] Putkey object created." << endl;
}

Putkey::~Putkey(){
    cout << "[*] Putkey object deleted." << endl;
}

json Putkey::putkey(Request& request){
    // putkey handler
    json fail_payload;
    fail_payload["r"] = 0;

    cout << "[*] putkey handler called." << endl;
    string tmp_key;
    json payload_data;
    char* buf = new char[MAXLEN];
    request.get_request_data()->get_payload(buf);
    try{
        cout << buf << endl;
        payload_data = json::parse(buf);
    }
    catch(...){
        cout << "[-] putkey parse json error." << endl;
        return FAIL;
    }
    for(auto iter = payload_data.begin(); iter != payload_data.end(); iter++){
        if(!iter.key().compare("k")){
            tmp_key = (string) iter.value();
            break;
        }
    }
    if(tmp_key.length() != 32){
        cout << "[-] wrong key length" << endl;
        return fail_payload;
    }
    enc_key = tmp_key;    // set key
    json succ;
    succ["r"] = 1;
    return succ;
}

Logout::Logout(){
    cout << "[*] Logout object created." << endl;
}

Logout::~Logout(){
    cout << "[*] Logout object deleted." << endl;
}

int Logout::logout(){
    // logout handler
    cout << "[*] logout handler called." << endl;
    enc_key = "";
    encsession = 0;
    return SUCCESS;
}

GetLogo::GetLogo(){
    cout << "[*] GetLogo object called." << endl;
}

GetLogo::~GetLogo(){
    cout << "[*] Getlogo object deleted." << endl;
}

json GetLogo::getlogo(string path){
    json fail_payload;
    fail_payload["r"] = 0;
    cout << "[*] getlogo handler called." << endl;
    if(path.length() >= 15){
        cout << "[-] filename too long." << endl;
        return fail_payload;
    }
    char* tmp_path = new char[100];
    snprintf(tmp_path, max_filename_len, logo_path_format.c_str(), path.c_str());  // BUG
    // open and read file
    cout << tmp_path << endl;
    ifstream cf(tmp_path);
    if(!cf.is_open()){
        cout << "[-] open logo file failed." << endl;
        return fail_payload;
    }
    string content;
    string buf;
    while(getline(cf, buf)){
        content += buf;
    }
    json succ;
    succ["r"] = 1;
    succ["d"] = content;
    return succ;
}

Ping::Ping(){
    cout << "[*] Ping object created." << endl;
}

Ping::~Ping(){
    cout << "[*] Ping object deleted" << endl;
}

void Ping::set_ip_address(string ip){
    ip_address = ip;
}

void Ping::set_count(unsigned int _count){
    count = _count;
}

json Ping::ping(){
    json fail_payload;
    fail_payload["r"] = 0;
    // check ip address
    string block1 = "`";
    string block2 = "&";
    string block3 = "|";
    string block4 = ";";
    string block6 = " ";
    string block7 = "/";
    if(ip_address.length() > 64){
        return fail_payload;
    }
    if(ip_address.find(block1) != string::npos || ip_address.find(block2) != string::npos || ip_address.find(block3) != string::npos || ip_address.find(block4) != string::npos || ip_address.find(block6) != string::npos || ip_address.find(block7) != string::npos){
        return fail_payload;
    }
    if(count > 10){
        return fail_payload;
    }
    char* cmd = new char[MAXLEN];
    string file_to_exec1 = "p";
    string file_to_exec2 = "i";
    string file_to_exec3 = "n";
    string file_to_exec4 = "g";
    string file_to_exec = file_to_exec1 + file_to_exec2 + file_to_exec3 + file_to_exec4;
    string param0 = " ";
    string param1 = "-";
    string param2 = "c";
    string param = param0 + param1 + param2;
    string tmp_format = "%d";
    string tmp_format2 = "%s";
    string tmp_cmd = file_to_exec + param + param0 + tmp_format + param0 + tmp_format2;
    sprintf(cmd, tmp_cmd.c_str(), count, ip_address.c_str());
    system(cmd);
    json succ;
    succ["r"] = 1;
    return succ;
}

Check::Check(){
    cout << "[*] Check object created." << endl;
}

Check::~Check(){
    cout << "[*] Check object deleted." << endl;
}

int Check::key_check(Request& request){
    cout << "[*] key_check called." << endl;
    // decode user input data first
    string tmp_decode;
    char* _buf = new char[MAXLEN];
    request.get_request_data()->get_payload(_buf);
    string tmp_encode = _buf;
    tmp_decode = base64_decode(tmp_encode);
    request.get_request_data()->set_payload((char*)tmp_decode.c_str());

    string tmp_key;
    json payload_data;
    char* buf = new char[MAXLEN];
    request.get_request_data()->get_payload(buf);
    // dec data
    do_enc_dec(buf, request.get_data_len());
    try{
        payload_data = json::parse(buf);
    }
    catch(...){
        cout << "[-] key check parse json error." << endl;
        return FAIL;
    }
    for(auto iter = payload_data.begin(); iter != payload_data.end(); iter++){
        if(!iter.key().compare("k")){
            tmp_key = (string) iter.value();
            break;
        }
    }
    if(enc_key.empty() || tmp_key.compare(enc_key)){
        cout << "[-] key_check failed." << endl;
        return FAIL;
    }
    request.get_request_data()->set_payload(buf);
    return SUCCESS;
}

int Check::crc_check(Request& request){
    cout << "[*] crc_check called." << endl;
    char* buf = new char[MAXLEN];
    request.get_request_data()->get_payload(buf);
    unsigned int _crc = crc32((const unsigned char*)buf, request.get_data_len());
    if(request.get_CRC() != _crc){
        cout << "[-] CRC check failed" << endl;
        return FAIL;
    }
    return SUCCESS;
}

int Check::encsession_check(Request& request){
    cout << "[*] encsession_check called." << endl;
    unsigned int tmp_encsession;
    tmp_encsession = request.get_request_data()->get_encsession();
    if(encsession == 0 || tmp_encsession != encsession){
        cout << "[*] encsession_check failed" << endl;
        return FAIL;
    }
    return SUCCESS;
}

int do_enc_dec(char* buf, unsigned int length){
    cout << "[*] do_enc_dec called." << endl;
    if(enc_key.length() != 32){
        cout << "[-] Odd! enc_key lost." << endl;
        return FAIL;
    }
    if(length > MAXLEN){
        cout << "[-] dec failed, data too long" << endl;
        return FAIL;
    }
    int i = 0, j = 0;
    while(1){
        if(i >= length){
            break;
        }
        if(j >= 32){
            j = 0;
        }
        buf[i] = buf[i] ^ enc_key.c_str()[j];
        i++;
        j++;
    }
    return SUCCESS;
}

int get_input(char *buf)
{
    char c;
    int i = 0;
    while (i < MAXLEN)
    {
        read(0, &c, 1);
        if (c == '\n')
        {
            break;
        }
        buf[i] = c;
        i++;
    }
    return i;
}

void get_output(Response& response, json& _response_data){
    cout << "[*] Create response payload..." << endl;
    time_t t = time(0);
    response.set_timestamp((unsigned int) t);
    ResponseData* responseData = response.get_response_data();
    responseData->set_status(1);
    responseData->set_encflag(0);
    responseData->set_payload((char*)_response_data.dump().c_str());    // bug here?
    unsigned int _crc = crc32((const unsigned char*)_response_data.dump().c_str(), _response_data.dump().length());
    response.set_CRC(_crc);
    response.set_data_len(MAXLEN);
    cout << "[*] Header created" << endl;

    unsigned int version = response.get_version();
    unsigned int timestamp = response.get_timestamp();
    unsigned int crc = response.get_CRC();
    unsigned int datalen = response.get_data_len();
    unsigned int status = response.get_response_data()->get_status();
    unsigned int encflag = response.get_response_data()->get_encflag();
    char* buf = new char[MAXLEN];
    response.get_response_data()->get_payload(buf);

    cout << MAGIC;
    cout << (unsigned char) (version & 0xff) << (unsigned char) ((version >> 8) & 0xff) << (unsigned char) ((version >> 16) & 0xff) << (unsigned char) ((version >> 24) & 0xff);
    cout << (unsigned char) (timestamp & 0xff) << (unsigned char) ((timestamp >> 8) & 0xff) << (unsigned char) ((timestamp >> 16) & 0xff) << (unsigned char) ((timestamp >> 24) & 0xff);
    cout << (unsigned char) (crc & 0xff) << (unsigned char) ((crc >> 8) & 0xff) << (unsigned char) ((crc >> 16) & 0xff) << (unsigned char) ((crc >> 24) & 0xff);
    cout << (unsigned char) (datalen & 0xff) << (unsigned char) ((datalen >> 8) & 0xff) << (unsigned char) ((datalen >> 16) & 0xff) << (unsigned char) ((datalen >> 24) & 0xff);
    cout << (unsigned char) (status & 0xff) << (unsigned char) ((status >> 8) & 0xff) << (unsigned char) ((status >> 16) & 0xff) << (unsigned char) ((status >> 24) & 0xff);
    cout << (unsigned char) (encflag & 0xff) << (unsigned char) ((encflag >> 8) & 0xff) << (unsigned char) ((encflag >> 16) & 0xff) << (unsigned char) ((encflag >> 24) & 0xff);
    cout << buf;
}

unsigned int crc32(const unsigned char *buf, int size) {
    unsigned int i, crc;
    crc = 0x0;
    for(i = 0; i < size; i++)
    crc = crc32tab[(crc ^ buf[i]) & 0xff] ^ (crc >> 8);
    return crc ^ 0xFFFFFFFF;
}

int main()
{
    io_init();
    char *buf = new char[MAXLEN];
    Parser parser;
    Response response;
    Check check;
    response.set_magic(0x4d554c4245525259);
    response.set_version(1);
    json fail_payload;
    fail_payload["r"] = 0;
    while(1){
        int len = get_input(buf);
        if(len > MAXLEN){
            cout << "[-] Input too long!" << endl;
            break;
        }
        Request req;
        int status = parser.parseRequest(buf, len, req);    // parse request
        if(!status){
            cout << "[-] parse request error." << endl;
            break;
        }
        // check opcodes
        int req_opcode = req.get_request_data()->get_opcode();
        switch (req_opcode)
        {
            case 0:    // login
            {
                // check crc first
                if(!check.crc_check(req)){
                    get_output(response, fail_payload);
                    break;
                }
                string u_username;
                string u_password;
                char* tmp_login_payload = new char[MAXLEN];
                req.get_request_data()->get_payload(tmp_login_payload);
                json payload_data;
                try{
                    payload_data = json::parse(tmp_login_payload);
                }
                catch(...){
                    cout << "[-] json parse error." << endl;
                    break;
                }
                for(auto iter = payload_data.begin(); iter != payload_data.end(); iter++){
                    if(!iter.key().compare("u")){    // found user's input username
                        u_username = (string)iter.value();
                    }
                    else if(!iter.key().compare("p")){    // found user's input password
                        u_password = (string)iter.value();
                    }
                }
                json _response_data;
                Login _login;
                _login.set_username(u_username);
                _login.set_password(u_password);
                _response_data = _login.login();    // handler
                get_output(response, _response_data);
                break;
            }

            case 1:    // put key
            {
                if(!check.crc_check(req)){
                    get_output(response, fail_payload);
                    break;
                }
                if(!check.encsession_check(req)){
                    get_output(response, fail_payload);
                    break;
                }
                // putkey handler
                Putkey putkey;
                json _response_data;
                _response_data = putkey.putkey(req);
                get_output(response, _response_data);
                break;
            }

            case 2:    // logout
            {
                if(!check.crc_check(req)){
                    get_output(response, fail_payload);
                    break;
                }
                if(!check.encsession_check(req)){
                    get_output(response, fail_payload);
                    break;
                }
                if(!check.key_check(req)){
                    get_output(response, fail_payload);
                    break;
                }
                Logout logout;
                logout.logout();
                break;
            }

            case 3:    // get logo
            {
                if(!check.crc_check(req)){
                    get_output(response, fail_payload);
                    break;
                }
                char* buf = new char[MAXLEN];
                req.get_request_data()->get_payload(buf);
                json tmp_payload;
                try{
                    tmp_payload = json::parse(buf);
                }
                catch(...){
                    cout << "[-] get logo parse payload failed." << endl;
                    break;
                }
                string tmp_path;
                for(auto iter = tmp_payload.begin(); iter != tmp_payload.end(); iter++){
                    if(!iter.key().compare("d")){
                        tmp_path = (string)iter.value();
                    }
                }
                GetLogo getlogo;
                json response_payload;
                response_payload = getlogo.getlogo(tmp_path);
                get_output(response, response_payload);
                break;
            }

            case 4:    // ping handler
            {
                if(!check.crc_check(req)){
                    get_output(response, fail_payload);
                    break;
                }
                if(!check.encsession_check(req)){
                    get_output(response, fail_payload);
                    break;
                }
                if(!check.key_check(req)){
                    get_output(response, fail_payload);
                    break;
                }
                char* buf = new char[MAXLEN];
                req.get_request_data()->get_payload(buf);
                json tmp_payload;
                try{
                    tmp_payload = json::parse(buf);
                }
                catch(...){
                    cout << "[-] ping parse payload failed." << endl;
                    break;
                }
                string tmp_ip_address;
                unsigned int tmp_count;
                for(auto iter = tmp_payload.begin(); iter != tmp_payload.end(); iter++){
                    if(!iter.key().compare("i")){
                        tmp_ip_address = (string)iter.value();
                    }
                    if(!iter.key().compare("c")){
                        tmp_count = (unsigned int) iter.value();
                    }
                }
                Ping ping;
                ping.set_ip_address(tmp_ip_address);
                ping.set_count(tmp_count);
                json response_payload;
                response_payload = ping.ping();
                get_output(response, response_payload);
                break;
            }
        
            default:
                break;
        }
    }
    return 0;
}