#define SUCCESS 1
#define FAIL    0

class Parser
{
    public:
        Parser();
        ~Parser();
        int parseRequest(char* buf, int length, Request& request);
};